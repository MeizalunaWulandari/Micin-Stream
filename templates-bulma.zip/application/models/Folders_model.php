<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Folders_model extends CI_Model {

	public function create()
	{
		$data = [
			'folder_name' => $this->input->post('folder_name'),
			'slug' => url_title($this->input->post('folder_name'), 'dash', TRUE),
			'code' => random_string('alnum', 8),
			'user_id' => $this->session->userdata('user_id'),
			'is_deleted' => 0
		];

		$this->db->insert('folders', $data);
	}
	

}

/* End of file Folders_model.php */
/* Location: ./application/models/Folders_model.php */